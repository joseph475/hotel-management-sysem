$('.chooseRoomsLi:first').addClass('active');

