$(document).on('click','.update_hours', extendTime);
$(document).ready(loadFoodList);
$(document).ready(loadExtrasList);
$(document).on('click','.add_extras', showAddExtras);
$(document).on('click','.add_something', confirmAddSomething);

var myFoodList = $('.foodList');
var myExtrasList = $('.ExtrasList');
var addSomethingModal = $('#addFoodsExtrasModal');
var checkin_id = $('.checkin-status-page').attr('data-id');

var tobeCleared = ['#something_quantity']

function confirmAddSomething(){
    var id = addSomethingModal.find('#something_quantity').attr('data-id');
    var quantity = addSomethingModal.find('#something_quantity').val();

    $.ajax({
        url: '../api/AddExtras',
        type: 'post',
        data:{
            checkinId : checkin_id,
            extrasId : id,
            quantity : quantity
        },
        dataType: 'json',
        success: function (data) {
            M.toast({html: 'Added Succesfully'});
            clearModal(tobeCleared);
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log(textStatus, errorThrown);
        }
    });
}

function loadFoodList(){
    $.ajax({
        url: '../api/Kitchen/getPublishedFoods',
        type: 'get',
        dataType: 'json',
        success: function (data) {
            loopFoodlist(data);
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log(textStatus, errorThrown);
        }
    });
}

function loadExtrasList(){
    $.ajax({
        url: '../api/Extras/getPublishedExtras',
        type: 'get',
        dataType: 'json',
        success: function (data) {
            loopExtraslist(data);
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log(textStatus, errorThrown);
        }
    });
}

function loopExtraslist(data) {
    myExtrasList.html("");
    for (var i = 0; i < data.length; i++) {
        var id = data[i].id
            description = data[i].description,
            cost = data[i].cost,
            myExtrasList.append(createExtrasList(id, description, cost));
    }
}


function loopFoodlist(data) {
    myFoodList.html("");
    for (var i = 0; i < data.length; i++) {
        var id = data[i].id
            menuName = data[i].menuName,
            remaining = data[i].remaining,
            sellingPrice = data[i].sellingPrice
            myFoodList.append(createFoodList(id, menuName, remaining, sellingPrice));
    }
}

function createExtrasList(id, description, cost) {
    var myExtras = '<li data-id="'+ id +'" data-name="'+ description +'" data-type="Extras">' + description + 
                        '<span class="right">&#8369;' + cost +
                            '<a href="#addFoodsExtrasModal" class="addbtn ml30 add_extras modal-trigger">' +
                                '<i class="far fa-plus-square fa-lg"></i>' +
                            '</a>' +
                        '</span>' +
                  '</li>';
    return myExtras;
}

function createFoodList(id, menuName, remaining, sellingPrice) {
    var myFood = '<li data-id="'+ id +'" data-name="'+ menuName +'" data-count="'+ remaining +'" data-type="Foods">' + menuName + 
                        '<span class="right">&#8369;' + sellingPrice +
                            '<a class="addbtn ml30 modal-trigger">' +
                                '<i class="far fa-plus-square fa-lg"></i>' +
                            '</a>' +
                        '</span>' +
                  '</li>';
    return myFood;
}

function extendTime(){
    var rate_id = $('input[name=roomRate]:checked').attr('data-id');
    var hours = $('input[name=roomRate]:checked').val();
    $.ajax({
        url: '../api/ExtendTime',
        type: 'POST',
        data: {
            checkin_id : checkin_id,
            raterefno: rate_id,
            hours: hours
        },
        dataType: 'json',
        success: function (data) {
            M.toast({html: 'Check-out Time Extended'});
            location.reload();
        },
        error: function (aaa, bbb, ccc) {
            console.log(aaa + "-" + bbb + "-" + ccc);
        }
    });
}

function showAddExtras(){
    var id = $(this).closest('li').attr('data-id');
    var name = $(this).closest('li').attr('data-name');
    addSomethingModal.find('h4').html('Add ' + name);
    addSomethingModal.find('#something_quantity').attr('data-id', id);
}
